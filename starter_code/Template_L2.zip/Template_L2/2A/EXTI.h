/*
 * ECE 153B - Winter 2021
 *
 * Name(s):
 * Section:
 * Lab: 2A
 */

#ifndef __STM32L476G_NUCLEO_EXTI_H
#define __STM32L476G_NUCLEO_EXTI_H

#include "stm32l476xx.h"

void EXTI_Init(void);

#endif
