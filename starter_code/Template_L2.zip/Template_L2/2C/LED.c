/*
 * ECE 153B - Winter 2021
 *
 * Name(s):
 * Section:
 * Lab: 2C
 */

#include "LED.h"

void LED_Init(void) {
	// Enable GPIO Clocks
	// [TODO] 
	
	// Initialize Green LED
	// [TODO]
}

void Green_LED_Off(void) {
	// [TODO]
}

void Green_LED_On(void) {
	// [TODO]
}

void Green_LED_Toggle(void){
	// [TODO]
}
