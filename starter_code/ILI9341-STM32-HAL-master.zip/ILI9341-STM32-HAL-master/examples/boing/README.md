Port of Arduino sketch `pyportal_boing` (included with `Adafruit_ILI9341` Arduino library) using this ILI9341-STM32-HAL library for STM32 Nucleo devices

Original source code by Adafruit: [adafruit/Adafruit_ILI9341/tree/master/examples/pyportal_boing](https://github.com/adafruit/Adafruit_ILI9341/tree/master/examples/pyportal_boing)


