#include "SPI.h"

// Note: When the data frame size is 8 bit, "SPIx->DR = byte_data;" works incorrectly. 
// It mistakenly send two bytes out because SPIx->DR has 16 bits. To solve the program,
// we should use "*((volatile uint8_t*)&SPIx->DR) = byte_data";

void SPI1_GPIO_Init(void) {
	// TODO: initialize SPI1 GPIO pins
}

void SPI1_Init(void){
	// TODO: initialize SPI1 peripheral as master
}

void SPI2_GPIO_Init(void) {
	// TODO: initialize SPI2 GPIO pins
}

void SPI2_Init(void){
	// TODO: initialize SPI2 peripheral as slave
}
 
void SPI_Send_Byte(SPI_TypeDef* SPIx, uint8_t write_data) {
	// TODO: send data from SPI1
}

void SPI_Receive_Byte(SPI_TypeDef* SPIx, uint8_t* read_data) {
	// TODO: receive data from SPI2
}

