/*
 * ECE 153B - Winter 2021
 *
 * Name(s):
 * Section:
 * Lab: 4C
 */

#include "LED.h"

void LED_Init(void) {
	// TODO
}

