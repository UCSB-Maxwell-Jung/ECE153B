/*
 * ECE 153B - Winter 2023
 *
 * Name(s):
 * Section:
 * Lab: 6A
 */

#include "stm32l476xx.h"

void GPIO_Init(void){	
	// [TODO]
}


#define DELAY 60000	// delay between steps of the sequences

void Full_Stepping_Clockwise(void){
	// [TODO]
}

void Full_Stepping_CounterClockwise(void){
	// [TODO]
}

void Half_Stepping_Clockwise(void){
	// [TODO]	
}

void Half_Stepping_CounterClockwise(void){
	// [TODO]
}


int main(void){
	GPIO_Init();
	
	// Rotate 360 degrees either clockwise or counter-clockwise
	// [TODO]
}
