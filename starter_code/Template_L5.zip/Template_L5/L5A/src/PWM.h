#ifndef __STM32L476G_DISCOVERY_PWM_H
#define __STM32L476G_DISCOVERY_PWM_H

#include "stm32l476xx.h"

// [TODO] 

#endif /* __STM32L476G_DISCOVERY_PWM_H */
